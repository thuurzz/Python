# forca.py


def jogar():
    print(40 * '=')
    print('Bem vindo ao Jogo de Forca!')
    print(40 * '=')
    print('Fim de jogo.')


if __name__ == '__main__':
    jogar()
